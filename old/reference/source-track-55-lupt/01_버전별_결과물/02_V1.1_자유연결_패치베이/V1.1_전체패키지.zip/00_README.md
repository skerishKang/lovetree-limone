# LoveTree 55 — LUPT Free Wiring Patchbay V1.1

작성일: 2026-08-10  
상태: `CANDIDATE_FOR_PRODUCT_OWNER_REVIEW`

## 목적
V1의 실시간 routing / LUPT path walk 엔진을 보존하면서, 사용자가 직접 Moment의 OUT port에서 다른 Moment의 IN port로 Connection을 만드는 `USER-WIRABLE LIVING CONNECTION CANVAS` 후보를 검증한다.

## 계보
`Track 53 Node Light Flow` → path-following light / replay motion engine inheritance  
`Track 55 LUPT Living Connection Router V1` → live bundle routing / draggable LUPT junction  
`Track 55 V1.1` → free wiring / manual reroute / rewire / delete + undo / Memory Patchbay visual template

## 핵심 기능
- OUT → IN 직접 drag connection 생성
- 모바일 tap-to-connect fallback
- one-to-many / many-to-one
- deterministic auto routing + bundle lane spacing
- manual reroute handle 추가/이동
- destination endpoint rewire
- delete / 1-level 이상 undo stack
- Moment drag / LUPT drag 중 live reflow
- LUPT가 선택한 실제 SVG path를 `getTotalLength()` / `getPointAtLength()`로 이동
- WHY NEXT? relation 입력/표시
- AUTO TIDY / + MOMENT / RESET / mobile zoom

## 초기 데모
- Moment 7개
- 초기 Connection 3개만 pre-wired
- 나머지는 사용자가 직접 연결
- + MOMENT 시 미연결 Moment 08 생성

## Visual Template
`Premium Memory Patchbay / Living Cable Loom`
- charcoal / graphite micro-dot board
- smoked acrylic compact Moment cards
- recessed patch sockets
- cable body + colored fiber + active light + hot tip/trail
- Inter/Pretendard/Noto Sans KR/Segoe UI 기반 sans-serif
- cyan / violet / rose / ivory LUPT core 유지

## 검증 결과 요약
Desktop 1440×960:
- Connection create 6/6
- same source multi-connect 4 connections
- many-to-one 3 source connections
- manual junction 3/3
- rewire 3/3
- delete/undo 3/3
- Moment live drag PASS
- LUPT live drag PASS
- selected real-path walk PASS
- endpoint max gap 0.000029px 미만
- console/page error 0
- horizontal overflow 0

Mobile 390×844:
- tap-to-connect 3/3
- connection select 3/3
- delete/undo 2/2
- long-press bend PASS
- Moment touch drag PASS
- LUPT touch drag PASS
- port touch hit target 약 38.64px
- console/page error 0
- horizontal overflow 0

실행영상은 합성 리뷰가 아니라 실제 Chromium 페이지를 Playwright browser recording으로 기록한 27.97초 실행본이다.
