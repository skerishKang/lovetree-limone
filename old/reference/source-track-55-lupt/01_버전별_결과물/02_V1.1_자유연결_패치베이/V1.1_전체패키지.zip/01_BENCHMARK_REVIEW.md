# 55 V1.1 — Benchmark Raw Review

원본: `참고-녹화_2026_08_09_17_12_36_587.mp4`  
직접 확인값: 1920×1080 / 30fps / 17.182766초

## 직접 확인한 핵심 동작

### 1. Parallel Bundle
약 3.5~8.2초 구간에서 여러 cable이 entry reroute point로 모인 뒤, 완전히 한 줄로 merge되지 않고 일정 간격의 평행 lane으로 trunk를 공유한다. 각 cable identity가 유지된다.

### 2. Junction / Reroute Movement
약 8~13초 구간에서 중간 reroute 위치가 달라질 때 source/destination attachment는 유지되고, shared segment와 bend 길이가 함께 재배치된다. 핵심 감각은 선이 새로 그려지는 것이 아니라 이미 연결된 cable loom이 손에 따라 재정렬되는 것이다.

### 3. Endpoint Continuity
노드 또는 reroute가 움직여도 cable endpoint가 socket에서 떨어지지 않는다. topology 변화가 순간이동처럼 끊기지 않고 연속적으로 보인다.

### 4. Fan-out / Identity
shared trunk 이후 목적 socket 쪽에서 개별 cable이 다시 갈라진다. bundle을 쓰더라도 개별 cable이 겹쳐 한 선으로 사라지지 않는다.

### 5. Final Tidy State
후반 약 15.8초 구간에서는 길어진 routing이 다시 정돈된 평행 cable 구조로 수렴한다. 이것이 V1.1의 `LUPT FINDS THE PATH` 행동 기준이다.

## V1.1로 변환한 항목
Benchmark node → LoveTree Moment Card  
Socket → Moment IN/OUT patch port  
Cable → directional Connection  
Shared cable loom → Emotional Path bundle  
Reroute point → manual bend + LUPT junction  
Node move → Moment live drag  
Cable reroute → deterministic live reflow  
Cable identity → 각 Connection relation / WHY NEXT? 보존

## 차이점 — 의도적 비복제
- Blender node UI/브랜드/컬러를 복제하지 않는다.
- 사용자는 관계(source/target)를 선택하고 LUPT가 route를 정리한다.
- Connection은 `내가 이 Moment를 본 뒤 왜 다음 Moment로 갔는가`라는 방향성 있는 감정 관계다.
- 시각 template은 `Memory Patchbay / Living Cable Loom`으로 별도 설계한다.

## Benchmark fidelity 판단
V1.1은 원본의 핵심 행동인 `port attachment → parallel bundle → reroute movement → live reflow → fan-out → identity preservation`을 실제 interactive SVG routing으로 재현한다. 픽셀/GUI 복제가 아니라 cable-management behavior의 제품 번역을 목표로 한다.
