# 55 V1.1 — Interaction Spec

## Product Rule
**USER CHOOSES THE RELATION. LUPT FINDS THE PATH.**

## Data Model
`moments[]`는 `{id, x, y, title, emotion, source...}`를 가진다.  
`connections[]`는 최소 `{id, sourceMomentId, sourcePort:'out', targetMomentId, targetPort:'in', relation, manualJunctions:[]}`를 가진 mutable state다.

Connection 생성/삭제/rewire는 실제 배열을 변경한 후 동일 routing engine으로 geometry를 재계산한다. fixed SVG path 문자열만 교체하는 mockup이 아니다.

## 1. Free Connection
Desktop: OUT port pointerdown → preview cable → valid IN glow → target release → Connection 생성 → relation editor.  
Mobile: OUT tap → armed state → valid IN tap → Connection 생성. Drag connect도 pointer 환경에서 동작한다.

동일 exact source→target 중복만 막고, source OUT과 target IN은 여러 Connection을 허용한다.

## 2. One-to-Many / Many-to-One
- 같은 source OUT에서 여러 target IN으로 반복 생성 가능
- 여러 source OUT에서 같은 target IN으로 반복 생성 가능
- port 중심에서 출발한 cable은 짧은 segment 뒤 routing lane으로 분리되어 identity를 유지

## 3. Auto Routing
우선순위:
1. endpoint 정확성
2. node collision 완화
3. manual junction 존중
4. shared trunk 활용
5. bundle lane spacing
6. curve smoothness

장거리/cross-column connection은 LUPT hub의 entry/exit 주변에 lane offset을 두어 bundle을 만들고, 짧은 local connection은 smooth midpoint curve를 사용한다.

## 4. Manual Bend
Desktop: selected Connection double-click 또는 inspector `+ BEND`.  
Mobile: Connection long-press.  
생성된 handle을 drag하면 source/target은 고정한 채 path가 pointermove 중 live reflow한다. `- BEND`로 제거 가능하다.

## 5. Destination Rewire
selected Connection에서 target endpoint handle을 드래그해 다른 Moment IN port에 놓으면 `targetMomentId`가 실제 state에서 변경된다. 그 뒤 route geometry를 다시 계산한다.

## 6. Delete / Undo
- Inspector `DELETE CONNECTION`
- keyboard Delete / Backspace
- mobile inspector action
- global/inspector `UNDO`

Undo는 state snapshot stack을 사용한다.

## 7. LUPT
- ROUTE: 새 Connection 생성 직후 route status 표시
- TIDY: AUTO TIDY가 shared hub를 정리하되 manual junction을 보존
- WALK: selected actual SVG path 위를 이동
- JUNCTION: LUPT drag가 hub-routed Connection bundle을 실시간 변경

## 8. Direction / Replay
평상시 cable은 clean fiber로 보이되, 선택 시 source glow / 작은 directional marker / hot traveling tip / destination arrival ring으로 `A → B` 방향을 명확히 한다.

## 9. Mobile Safety
- port visual은 compact하지만 pointer/touch hit area는 약 38px
- 2-column board
- Moment/LUPT drag clamp
- inspector는 compact bottom sheet
- tap-to-connect fallback 제공

## 10. Accessibility
- keyboard Moment focus/selection 가능
- selected state를 색 외 outline/label로 보조
- prefers-reduced-motion 대응
- 기본 privacy label은 `PRIVATE TREE`
