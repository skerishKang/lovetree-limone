# Mobile QA — 390×844

- Tap-to-connect create: 3/3 PASS
- Connection select by actual cable tap: 3/3 PASS
- Delete + undo: 2/2 PASS
- Long-press manual bend: PASS
- Moment 1-finger touch drag: PASS
- LUPT 1-finger touch drag: PASS
- Port touch hit target width: 38.64px PASS
- Console/page errors: 0
- Horizontal overflow: 0
- Vertical overflow: 0

검증은 mouse-only 대체가 아니라 Chromium mobile context + touchStart/touchMove/touchEnd sequence를 사용했다.
