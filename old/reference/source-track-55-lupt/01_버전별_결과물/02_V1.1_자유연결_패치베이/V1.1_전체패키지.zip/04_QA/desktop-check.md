# Desktop QA — 1440×960

- Connection create: 6/6 PASS
- Same-source multi-connect: 4 connections PASS (requirement ≥3)
- Many-to-one: 3 distinct source connections PASS (requirement ≥2)
- Manual reroute add + drag: 3/3 PASS
- Destination rewire: 3/3 PASS
- Delete + undo: 3/3 PASS
- Moment drag pointermove live reflow: PASS
- LUPT drag pointermove shared-route reflow: PASS
- Selected real SVG path walk + arrival: PASS
- Endpoint max gap to port center: 0.0000285px PASS
- Console/page errors: 0
- Horizontal overflow: 0
- Vertical overflow: 0
