# Desktop QA — 1440×960

결과: **PASS (interaction hard-fail 기준)**

- 초기 Moment: 7
- 초기 Connection: 10
- + MOMENT 후 Moment: 8
- + MOMENT 후 Connection: 11
- console/page error: 0
- horizontal overflow: 없음
- source path endpoint와 Moment port/card side 중심 오차: 약 1px 이내
- Moment pointermove 중 connection `d` 값 실시간 변화: PASS
- LUPT pointermove 중 bundle connection `d` 값 실시간 변화: PASS
- Connection 선택 후 `state.walking=true`: PASS
- 실제 path length sampling 완료 후 `state.walking=false`: PASS
- 새 Moment e11 생성 및 bundle routing: PASS
- dead button 발견 없음

## Standalone 환경 제한
테스트 런타임의 보안 정책이 `file://` 및 `data:` navigation을 `ERR_BLOCKED_BY_ADMINISTRATOR`로 막습니다. 따라서 브라우저 QA는 동일한 standalone HTML bytes를 `page.set_content()`로 실행했습니다. HTML은 외부 script/image/network dependency가 없는 단일 파일이며 syntax check도 PASS했습니다.
