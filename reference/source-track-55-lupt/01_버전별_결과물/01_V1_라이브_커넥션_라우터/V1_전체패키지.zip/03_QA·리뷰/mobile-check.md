# Mobile QA — 390×844

결과: **PASS (V1 mobile interaction 기준)**

- 초기 zoom: 86%
- horizontal overflow: 없음
- card 좌/우 영구 이탈: 없음
- 실제 화면 기준 최소 left margin 약 9px
- Pointer Events + touch-action:none 적용
- Chrome DevTools `Input.dispatchTouchEvent` 실제 touch sequence로 Moment drag: PASS
- touch drag 중 Connection path live reflow: PASS
- 실제 touch sequence로 LUPT drag: PASS
- touch drag 중 bundle live reflow: PASS
- Connection tap/pointer selection 구조: PASS
- keyboard focus Moment: PASS
- keyboard Enter로 Connection 선택/걷기: PASS
- ± zoom controls: 제공
- console/page error: 0

Hover 전용 핵심 기능은 없습니다.
