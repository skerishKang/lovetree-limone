# LoveTree 55 — LUPT Living Connection Router V1

상태: **NEW CANDIDATE / PRODUCT OWNER REVIEW 전**  
담당: LoveTree 디자인팀장 5기  
Production 반영: **아님**

## 한 줄
Moment와 Connection을 실제로 움직일 수 있고, LUPT를 드래그하면 공유 감정 bundle 전체가 실시간으로 재배치되며, Connection을 선택하면 LUPT가 실제 SVG path geometry를 따라 걷는 standalone HTML 후보입니다.

## 루트 바로보기
- `★_최종선택_55_LUPT_LIVING_CONNECTION_ROUTER_V1_바로보기.html`
- `★_실행영상_55_LUPT_LIVING_CONNECTION_ROUTER_V1_브라우저녹화.mp4`

사용자가 폴더를 열었을 때 위 두 파일을 먼저 확인하면 됩니다.

## 폴더
- `01_설계·분석`: benchmark 해석과 interaction spec
- `02_HTML`: 작업 HTML 원본
- `03_QA·리뷰`: 데스크톱/모바일 QA, contact sheet, 검증 JSON

## 구현 핵심
- SVG connection routing
- source/destination Moment port anchor 유지
- bundle lane spacing 6px
- bundle별 entry / exit junction
- requestAnimationFrame 기반 live reflow batching
- transform/position 기반 Moment drag
- draggable LUPT junction
- Track 53 방식 `getTotalLength()` / `getPointAtLength()` path travel
- hot tip + fading trail
- arrival reaction + WHY NEXT relation chip
- `+ MOMENT` 기존 bundle 합류
- mobile Pointer Events / touch-action:none / ± zoom
- ResizeObserver
- prefers-reduced-motion

## 중요한 제한
작업지시서가 지정한 원본 `녹화_2026_08_09_17_12_36_587.mp4` 파일 자체는 이번 실행 환경의 Drive/File Library 검색에서 확보되지 않았습니다. 따라서 benchmark 동작 해석은 제품 오너 지시서에 기록된 17.17초 영상 분석을 기준으로 구현했습니다. **RAW benchmark frame-by-frame optical fidelity 검증은 미완료**입니다.

Track 53 standalone 원본은 Drive에서 회수하여 path-following 엔진 구조를 확인하고 재사용했습니다.
