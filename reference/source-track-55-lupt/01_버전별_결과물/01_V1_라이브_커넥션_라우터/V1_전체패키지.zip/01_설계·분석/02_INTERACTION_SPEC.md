# 55 Interaction Spec

## 1. Moment drag
- Pointer Events 사용
- pointerdown에서 초기 좌표/상태 캐시
- pointermove에서 normalized x/y만 갱신
- DOM 전체 layout read 없이 위치 적용
- route update는 requestAnimationFrame으로 batch
- card boundary clamp 적용

## 2. Bundle routing
초기: 7 Moment / 10 Connection / 3 bundle / 1 LUPT

각 Connection path:
1. source Moment horizontal port
2. bundle entry junction + lane offset
3. shared trunk + 동일 lane offset
4. bundle exit junction
5. destination Moment horizontal port

Lane spacing: **6px**. 완전 겹침 금지.

## 3. LUPT drag
LUPT는 별도 설명 캐릭터가 아니라 routing state를 갖는 junction입니다.
- drag 동안 `luptHome` 갱신
- entry / exit junction 재계산
- 모든 관련 SVG path live update
- LUPT 자체는 luminous core + 작은 eyes만 사용

## 4. Connection select / path follow
Connection을 선택하면:
- 비선택 skeleton opacity 감소
- 선택 skeleton 강화
- glow memory layer 활성화
- WHY NEXT relation chip 표시
- LUPT가 실제 path의 `getTotalLength()` / `getPointAtLength()`를 따라 이동
- hot tip + 18개 fading trail dot 동반
- destination Moment arrival pulse

## 5. WALK THIS PATH
main causal route:
`처음 본 무대 → 다른 직캠 → 인터뷰 → 팬미팅 → 결정적 순간`

현재 edge sequence: `e1 → e4 → e7 → e9`.

## 6. + MOMENT
새 Moment 08을 생성하고 `e11`을 final bundle에 합류시킵니다. 별도 고립 직선이 아니라 기존 shared route를 사용한 뒤 새 Moment로 fan-out합니다.

## 7. AUTO TIDY
LUPT junction을 권장 중심점으로 easing 복귀시키며, 그 동안 route가 매 프레임 재계산됩니다.

## 8. Mobile
- Pointer Events + `touch-action:none`
- 390×844에서 초기 zoom 86%
- card clamp
- Connection tap
- ± zoom 82~116%

## 9. Accessibility
- Moment는 `<button>`
- focus-visible 제공
- Connection hit path는 tabindex=0 + Enter/Space 선택
- LUPT tabindex=0 + Enter/Space path walk
- prefers-reduced-motion 대응
- private 표기 유지
