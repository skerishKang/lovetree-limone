# 55 Benchmark Analysis

## 근거 상태
- **확정/소스:** 제품 오너 1차 작업지시서에 기록된 benchmark 분석
- **사실:** 지시서상 원본은 `녹화_2026_08_09_17_12_36_587.mp4`, 약 17.17초, 1920×1080, 약 29.94fps
- **미확인:** 이번 실행 환경에서 원본 mp4 자체는 검색·회수되지 않아 직접 프레임 재검토하지 못함

## 이식해야 하는 본질
노드 모양이 아니라 **dynamic cable management behavior**입니다.

1. 여러 Connection이 일정 구간에서 bundle로 모임
2. 완전 merge가 아니라 평행 lane identity 유지
3. 공통 trunk 뒤 destination 근처에서 fan-out
4. entry/exit junction 존재
5. junction 이동 시 관련 bundle 실시간 reflow
6. Moment 이동 시 endpoint가 떨어지지 않음
7. path topology가 드래그 도중 순간이동하지 않음
8. spaghetti가 아니라 harness / cable loom처럼 정돈됨

## LoveTree 변환
- Node → Moment Card
- Socket → Moment Connection Port
- Cable → Connection
- Bundle → Shared Emotional Path
- Reroute → LUPT Junction
- Cable identity → WHY NEXT reason identity
- Cable reflow → Tree/Connection layout reflow

## V1 구현 결정
각 bundle은 하나의 공유 중심을 갖되 Connection마다 6px lane offset을 가집니다. LUPT의 home junction을 이동하면 main/lower/final bundle의 entry/exit 지점이 연속적으로 재계산됩니다. 각 path는 `source → entry lane → shared trunk → exit lane → destination`의 동일 topology를 유지합니다.

## Benchmark fidelity 판정
**PROVISIONAL / 원본 직접비교 전**입니다. Behavior contract는 구현했지만 raw benchmark와 좌우 비교 영상은 원본 파일 확보 후 별도 검증해야 합니다.
