# LoveTree 55 — LUPT Free Wiring V1.2

상태: **CANDIDATE / PRODUCT OWNER DIRECT-MANIPULATION REVIEW**

## 이번 수정의 핵심
V1.1 routing engine은 정상 동작했다. V1.2는 사용자가 `OUT에서만 시작해야 한다`는 규칙을 외우지 않도록 interaction contract를 수정한다.

- OUT → IN 유지
- IN → OUT 신규 지원, 내부 의미는 동일한 OUT=source / IN=target
- Card-edge Magnetic Snap
- Invalid drop reason을 pointer 근처에서 표시
- Duplicate는 기존 edge 자동 선택
- WALK 중 socket 조작 우선
- idle .72 / selected 1 / dimmed .38 / memory .44로 가독성 보강
- HOW TO WIRE + 상태 legend
- V1.1의 one-to-many / many-to-one / bend / rewire / delete / undo / LUPT path walk 유지

## 폴더
- `01_설계`: 변경 요약
- `02_HTML`: main + standalone
- `03_QA`: 직접조작 검증
- `04_리뷰`: 실제 브라우저 실행영상과 proof sheet
- `★_55_LUPT_FREE_WIRING_V1.2_사용설명서.txt`: 사용자 설명서

Production 반영 없음. V1/V1.1 덮어쓰기 없음.
