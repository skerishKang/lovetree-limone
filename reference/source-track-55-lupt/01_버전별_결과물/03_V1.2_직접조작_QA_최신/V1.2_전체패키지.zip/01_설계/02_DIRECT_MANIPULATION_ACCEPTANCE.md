# V1.2 Direct Manipulation Acceptance

The routing engine itself was not the failure. The V1.1 gesture contract was too strict.

V1.2 acceptance principle:
- user may start from either socket;
- semantic direction remains OUT → IN internally;
- target acquisition supports exact socket and magnetic card edge;
- invalid gestures explain themselves at the pointer;
- duplicate relation selects the existing Connection;
- user input interrupts WALK instead of being ignored;
- other cables remain readable while one is selected.

This preserves Track 55's product rule: **the user chooses the relation; LUPT finds the path.**
