# Desktop QA — 55 LUPT Free Wiring V1.2
Viewport: 1440×960 / Chromium

- OUT → IN: 6/6 PASS
- IN → OUT: 6/6 PASS
- exact port center drop: 3/3 PASS
- card-edge magnetic snap (14px inside edge): 3/3 PASS
- OUT → OUT feedback: PASS / CONNECT OUT TO IN
- IN → IN feedback: PASS / CONNECT IN TO OUT
- SELF feedback: PASS / SAME MOMENT CANNOT CONNECT TO ITSELF
- DUPLICATE: PASS / THIS PATH ALREADY EXISTS + existing edge auto-selected
- one source → targets: 6 outgoing simultaneously
- sources → one target: 5 incoming simultaneously
- manual bend add/drag: 3/3 PASS
- destination rewire: 3/3 PASS
- delete/undo: 3/3 PASS
- Moment drag live reflow: PASS
- LUPT drag live reflow: PASS
- WALK → arrival / WHY NEXT?: PASS
- WALK 중 socket wiring 우선: PASS; WALK cancels and new connection is created
- selected opacity: 1.0
- dimmed opacity: 0.38
- idle opacity: 0.72
- completed memory opacity: 0.44
- maximum endpoint-to-socket-center gap: 0.0191 px
- horizontal overflow: 0
- vertical overflow: 0
- console/page errors: 0
